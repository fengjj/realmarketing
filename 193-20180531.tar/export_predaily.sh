. ~/.bash_profile

data_dir=/data1/windowdata/export/
cd $data_dir
dir_name=`date +'%Y%m%d'`

esp=132.98.23.31:19011/mywork/preflowevent
echo `date +%F/%T`
echo ''>preDailyFlowWindow
for((i=0;i<10;i++))
do
    echo "export: "${esp}${i}
    esp_query -p ${esp}${i} -c sap:sap123 -Q "select * from UserDailyFlowWindow  where FlowDate='${dir_name}'" >>preDailyFlowWindow &
    esp_query -p ${esp}${i} -c sap:sap123 -Q "select Msisdn, RoamType,Servid, SumDataFlow,LeftFlow,FlowTime,PayType,FlowDate,HomeAreaCode,VisitAreaCode,Userid,MinFlowTime from UserDataPreFlow2Window where FlowDate='${dir_name}'" >preflowevent_day_${i} &
done

echo `date +%F/%T`
echo "done-->${data_dir}"
exit
