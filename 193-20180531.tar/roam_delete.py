#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing

def loginfo(*info):
    logfile = "/data1/proc/roam_delete.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

def getFile():
    backupDir = "/data8/roam/backup/"
    localDir = "/data8/roam/dest/"
    remoteDir = "/GD_ROAM/"
    transport = paramiko.Transport(("132.96.56.74", 2222))
    transport.connect(username = "Gd_roam" , password = "Gd_roam123")
    tp = paramiko.SFTPClient.from_transport(transport)
    try:
        fileList = tp.listdir(remoteDir)
        if len(fileList) > 0:
            loginfo(str(len(fileList)))
            for fileName in fileList:
                loginfo("pid:", os.getpid(), " fileName -->", fileName)
                if (not ("tmp" in fileName) and ("txt" in fileName)):
                    remoteFile = os.path.join(remoteDir, fileName)
                    tp.remove(remoteFile)

    except Exception, ex:
        loginfo(os.getpid(), ",Exception", ex)
        tp.close()


if __name__ == "__main__":
    getFile()

