#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/sig_go.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

def updateFile(fileName):
    sigfile = "sig_file.cfg"
    with open(sigfile, 'w') as output:
        output.write(fileName)

def getFileName():
    sigfile = "sig_file.cfg"
    with open(sigfile, 'r') as sfile:
        return sfile.read()

def getFile(index,pros):
    try:
        backupDir = "/data4/prefile/sig_backup/"
        localDir = "/data4/prefile/sig/"
        remoteDir = "/data/uploads/sdtp/data_succ_backup/cs/"

        transport = paramiko.Transport(("132.98.16.169", 22))
        transport.connect(username = "stq_SS_CS" , password = "SSCS@2015stq")
        tp = paramiko.SFTPClient.from_transport(transport)
        lastFileName = getFileName()
        while 1:
            fileList = tp.listdir(remoteDir)
            if len(fileList) > 0:
                for fileName in fileList:
                    if not (fileName.startswith("SDTP")):
                        continue
                    if (fileName <= lastFileName):
                        continue
                    if(int(fileName[19:20]) % pros == index):
                        date = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]
                        #SDTP_CS_20170310111541586.DAT_20170310111858775
                        file_date = fileName + "_" + date
                        file_date = file_date.replace('DAT',fileName[8:25])
                        remoteFile = os.path.join(remoteDir,fileName)
                        backupFile = os.path.join(backupDir,file_date)
                        localFile = os.path.join(localDir,file_date)

                        tp.get(remoteFile, backupFile)
                        #shutil.copy(backupFile, localFile)
                        splitCmd = 'split -l 100000 %s %s_' % (backupFile, localFile)
                        os.popen(splitCmd)
                        os.remove(backupFile)

                        lastFileName = fileName
                        updateFile(fileName)
                        loginfo("pid:",os.getpid(),"-->",localFile)
            time.sleep(1.0)
    except Exception,ex:
        loginfo("Exception:",ex)
        os.popen("ps -ef |grep sig_go.py |grep -v grep|awk '{print $2}'|xargs kill -9")
        tp.close()
    finally:
        tp.close()

if __name__ == "__main__":
    pros = int(sys.argv[1])
    pool = multiprocessing.Pool(processes=pros)
    #0,1,2,3,4
    for index in range(0, pros):
        pool.apply_async(getFile, (index,pros))
    pool.close()
    pool.join()
