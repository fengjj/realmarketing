import ConfigParser                                                                                                                                                             
import string, os, sys                                                                                                                                                          
import paramiko                                                                                                                                                                 
import re                                                                                                                                                                       
import time,datetime                                                                                                                                                            
                                                                                                                                                                                
                                                                                                                                                                                
def init(paras,cfgname):                                                                                                                                                        
    print cfgname                                                                                                                                                               
    cf = ConfigParser.ConfigParser()                                                                                                                                            
    cf.read(cfgname)                                                                                                                                                            
    s = cf.sections()                                                                                                                                                           
    for board in cf.items('file'):                                                                                                                                              
        #print board[0]+'='+board[1]                                                                                                                                            
        if board[0] == 'src_dir':                                                                                                                                               
            paras[0] = board[1]                                                                                                                                                 
        if board[0] == 'dest_dir':                                                                                                                                              
            paras[1] = board[1]                                                                                                                                                 
    print  paras[0],paras[1]                                                                                                                                                    
    paras[2]=sys.argv[1]                                                                                                                                                        
                                                                                                                                                                                
def dealfile(paras):                                                                                                                                                            
                                                                                                                                                                                
    currentday=datetime.datetime.now().strftime("%Y%m%d%H%M")                                                                                                                   
    flowwindow_dict={}                                                                                                                                                          
    out_dict={}                                                                                                                                                                 
                                                                                                                                                                                
    flowwindow_file="%s/preDailyFlowWindow" % (paras[0])                                                                                                                        
    usedwindow_file="%s/preflowevent_day_%s" % (paras[0],paras[2])                                                                                                              
                                                                                                                                                                                
    file_object=open(flowwindow_file,'r')                                                                                                                                       
    for line in file_object:                                                                                                                                                    
        #print line                                                                                                                                                             
        Msisdn=line.split(' ')[1].split('=')[1].replace('"','')                                                                                                                 
        dataflow=(long)(line.split(' ')[4].split('=')[1].replace('"',''))                                                                                                       
        FlowDate=line.split(' ')[2].split('=')[1].replace('"','') 
        PayType=line.split(' ')[3].split('=')[1].replace('"','')                                                                                                              
        key_str="%s|%s" % (Msisdn,FlowDate)
        value_str="%ld,%s" %  (dataflow,PayType)                                                                                                                                    
        flowwindow_dict[key_str]=value_str
    print "num of flowwindow_dict:", len(flowwindow_dict)                                                                                                                       
    file_object.close()                                                                                                                                                         
                                                                                                                                                                                
    print "usedwindow_file=",usedwindow_file                                                                                                                                    
    file_object=open(usedwindow_file,'r')                                                                                                                                       
    for line in file_object:                                                                                                                                                    
                                                                                                                                                                                
                                                                                                                                                                                
        Msisdn=line.split(' ')[1].split('=')[1].replace('"','')                                                                                                                 
        #PayType=line.split(' ')[8].split('=')[1].replace('"','')                                                                                                                
        SumDataFlow=(long)(line.split(' ')[4].split('=')[1].replace('"',''))                                                                                                    
        FlowTime=line.split(' ')[6].split('=')[1].replace('"','')                                                                                                               
        MinFlowTime=line.split(' ')[12].split('=')[1].replace('"','')                                                                                                           
        HomeAreaCode=line.split(' ')[9].split('=')[1].replace('"','')                                                                                                           
        Userid=line.split(' ')[11].split('=')[1].replace('"','')                                                                                                                
        FlowDate=line.split(' ')[8].split('=')[1].replace('"','')                                                                                                               
        key_str="%s|%s" % (Msisdn,FlowDate)                                                                                                                                     
        if flowwindow_dict.has_key(key_str): 
            TotalDataFlow=(long)(flowwindow_dict[key_str].split(',')[0]) 
            PayType=flowwindow_dict[key_str].split(',')[1]                                                                                                                                  
            left_dataflow=TotalDataFlow-SumDataFlow                                                                                                                  
            out_value="%s,%s,%ld,%ld,%s,%s,%s,%s,%s,%ld" % (Msisdn,PayType,SumDataFlow,left_dataflow,FlowTime,MinFlowTime,HomeAreaCode,Userid,FlowDate,TotalDataFlow)
            out_dict[Msisdn]=out_value                                                                                                                                          
        else:                                                                                                                                                                   
                                                                                                                                                                                
            out_value="%s,%s,%ld,%ld,%s,%s,%s,%s,%s,%ld" % (Msisdn,PayType,SumDataFlow,0,FlowTime,MinFlowTime,HomeAreaCode,Userid,FlowDate,0)                                   
            out_dict[Msisdn]=out_value                                                                                                                                          
    print "num of out_dict:", len(out_dict)                                                                                                                                     
    file_object.close()                                                                                                                                                         
                                                                                                                                                                                
    outfile='%s/%s%s%s' % (paras[1],"UsedPreDailyDataFlowWindow",currentday,"00.txt")                                                                                           
    output = open(outfile, 'a')                                                                                                                                                 
    for k in out_dict.keys():                                                                                                                                                   
        output.writelines("%s\n" % (out_dict[k]))                                                                                                                               
    output.close()                                                                                                                                                              
                                                                                                                                                                                
                                                                                                                                                                                
                                                                                                                                                                                
def main(cfgname):                                                                                                                                                              
    paras=["","",""]                                                                                                                                                            
    init(paras,cfgname)                                                                                                                                                         
                                                                                                                                                                                
                                                                                                                                                                                
    print paras                                                                                                                                                                 
    dealfile(paras)                                                                                                                                                             
                                                                                                                                                                                
if __name__ == '__main__':                                                                                                                                                      
    main('daily.cfg')                                                                                                                                                        


