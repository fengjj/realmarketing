#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime

#动态输出日志
def loginfo(*info):
    logfile = "clear_backup.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

def rm(dir, timeName):
    fileList = os.listdir(dir)
    for dirOrFile in fileList:
        newDirOrFile = os.path.join(dir, dirOrFile)
        if os.path.isdir(newDirOrFile):
            if dirOrFile.startswith(timeName):
                rm(newDirOrFile, timeName)
                os.popen('rm -r ' + newDirOrFile)
                loginfo("pid:",os.getpid(),";clear:",newDirOrFile)
        else:
            os.remove(newDirOrFile)
            #loginfo("delete:",newDirOrFile)

if __name__ == "__main__":
    backupDir = sys.argv[1]
    day = int(sys.argv[2])
    sevenDayAgo = datetime.datetime.now() - datetime.timedelta(days=day)
    timeName = sevenDayAgo.strftime('%Y%m%d')
    rm(backupDir, timeName)
