. ~/.bash_profile

data_dir=/data1/windowdata/export/
cd $data_dir
dir_name=`date +'%Y%m%d'`

esp=132.98.23.30:19011/mywork/flowevent
echo `date +%F/%T`
for((i=0;i<10;i++))
do
    echo "export: "${esp}${i}
    esp_query -p ${esp}${i} -c sap:sap123 -Q "select Msisdn,FeeCode,DataFlow,LeftDataFlow,FlowTime,MinFlowTime,HomeAreaCode,Userid,FlowDate,TotalDataFlow from UsedDailyDataFlowWindow where FlowDate='${dir_name}' and DataType='3'" >flowevent_day_${i} &
    esp_query -p ${esp}${i} -c sap:sap123 -Q "select Msisdn,FeeCode,DataFlow,LeftDataFlow,FlowTime,MinFlowTime,HomeAreaCode,Userid,FlowDate,TotalDataFlow from UsedDailyDataFlowWindow where FlowDate='${dir_name}' and DataType='4'" >flowevent_day_4g_${i} &
done

echo `date +%F/%T`
echo "done-->${data_dir}${dir_name}"
exit
