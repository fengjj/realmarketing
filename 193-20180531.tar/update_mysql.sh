. ~/.bash_profile

cd /data1/proc/

#sql="update market.mk_event_info set event_type=\"15\", status_code=\"04\" where event_id = \"100003008\"; update market.mk_eventcontent_info set actconduct_par_value=\"LOC_SUB_PRO\" where event_id=\"100003008\" and actconduct_par_id=\"103203\";"

#sql="select actconduct_par_value from market.mk_eventcontent_info where event_id=\"201705081\" and actconduct_id=\"1002\" and actconduct_par_id=\"10021\";"

sql="update market.mk_eventcontent_info set actconduct_par_value=\"301705081\" where event_id=\"201705081\" and actconduct_id=\"1002\" and actconduct_par_id=\"10021\"; update market.mk_eventcontent_info set actconduct_par_value=\"201706022\" where event_id=\"201705081\" and actconduct_id=\"1002\" and actconduct_par_id=\"10023\";  "

mysql -h 132.98.16.196 -uroot -proot123 <<!
    #201708 
    ${sql}
!

echo [`date "+%Y-%m-%d %H:%M:%S"`] done:${sql} >>./update_mysql.log

