#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/dpi_go.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")


def getFile(index,pros):
        backupDir = "/data3/prefile/dpi_backup/"
        localDir = "/data3/prefile/dpi/"
        remoteDir = "/SSYXDY/"

        transport = paramiko.Transport(("132.96.56.72", 2222))
        transport.connect(username = "Gd_ssyx" , password = "Gd_ssyx1234!")
        tp = paramiko.SFTPClient.from_transport(transport)
        while 1:
            try:
                fileList = tp.listdir(remoteDir)
                if len(fileList) > 0:
                    for fileName in fileList:
                        if (not ("tmp" in fileName) and int(fileName[19]) % pros == index):
                            loginfo("1111")
                            remoteFile = os.path.join(remoteDir, fileName)
                            date = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]
                            # SSYXDY_20170309153927_636_183767.txt_20170309153936189
                            file_date = fileName + "_" + date
                            loginfo("2222")
                            file_date = file_date.replace('txt', fileName[7:21])
                            loginfo("3333")
                            hourbBackupDir = os.path.join(backupDir, date[:8])
                            loginfo("4444")
                            if not os.path.exists(hourbBackupDir):
                                os.mkdir(hourbBackupDir)
                            loginfo("5555")
                            backupFile = os.path.join(hourbBackupDir, file_date)
                            localFile = os.path.join(localDir, file_date)
                            loginfo("6666")

                            tp.get(remoteFile, backupFile)
                            tp.remove(remoteFile)
                            loginfo("7777")
                            shutil.copy(backupFile, localFile)
                            loginfo("pid:"+str(os.getpid())+"-->"+str(localFile))
                time.sleep(3.0)
            except Exception,ex:
		loginfo(os.getpid(),",Exception:",ex)
                if(ex.endswith("txt") or ex.endswith("tmp")):
                    loginfo(os.getpid(),",Exception:",ex)
                else:
                    loginfo("kill,Exception:",ex)
                    os.popen("ps -ef|grep python |grep dpi_go|awk '{print $2}'|xargs kill -9")
                    tp.close()

if __name__ == "__main__":
    pros = int(sys.argv[1])
    pool = multiprocessing.Pool(processes=pros)
    #0,1,2,3,4
    for index in range(0, pros):
        pool.apply_async(getFile, (index,pros))
    pool.close()
    pool.join()
