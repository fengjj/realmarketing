#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing
import zipfile

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/dpi_zip_go.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")


def getFile(index,pros):
    backupDir = "/data3/prefile/dpi_backup/"
    localDir = "/data3/prefile/dpi/"
    remoteDir = "/SSYXDY/"
    transport = paramiko.Transport(("132.96.56.72", 2222))
    transport.connect(username = "Gd_ssyx" , password = "Gd_ssyx1234!")
    tp = paramiko.SFTPClient.from_transport(transport)
    while 1:
        try:
            fileList = tp.listdir(remoteDir)
            if len(fileList) > 0:
                for fileName in fileList:
                    if (not ("tmp" in fileName) and int(fileName[19]) % pros == index):
                        remoteFile = os.path.join(remoteDir, fileName)
                        date = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]
                        hourbBackupDir = os.path.join(backupDir, date[:8])
                        if not os.path.exists(hourbBackupDir):
                            os.mkdir(hourbBackupDir)

                        backupFile = os.path.join(hourbBackupDir, fileName)
                        tp.get(remoteFile, backupFile)
                        tp.remove(remoteFile)
                        f = zipfile.ZipFile(backupFile, mode='r')
                        for file in f.namelist():
                            f.extract(file, hourbBackupDir)
                            os.remove(backupFile)
                            file_date = fileName + "_" + date
                            file_date = file_date.replace('zip', fileName[7:21])
                            shutil.copy(os.path.join(hourbBackupDir, fileName.replace('zip', 'txt')),
                                        os.path.join(localDir, file_date))
                        loginfo("pid:", os.getpid(), "-->", fileName)
            time.sleep(3.0)
        except Exception, ex:
            loginfo('error:', ex)
            if (ex.endswith("txt") or ex.endswith("tmp")):
                loginfo(os.getpid(), ",Exception:", ex)
            else:
                loginfo("kill,Exception:", ex)
                tp.close()
                os.popen("ps -ef|grep python |grep dpi_go|awk '{print $2}'|xargs kill -9")

if __name__ == "__main__":
    pros = int(sys.argv[1])
    pool = multiprocessing.Pool(processes=pros)
    #0,1,2,3,4
    for index in range(0, pros):
        pool.apply_async(getFile, (index,pros))
    pool.close()
    pool.join()
