. ~/.bash_profile
export NLS_LANG="AMERICAN_AMERICA.UTF8"

sqlplus DC_UNICOM/dc_uni#1@132.121.26.15:1521/dtcent_s2 <<!
	INSERT INTO hujia.sms_table_exp@LINK_NGBIL(SEND_FLAG,TEL_NUM,SMS_INFO,IN_DATE) VALUES('1','$1','$*',SYSDATE);
!
echo `date` $* >>/data1/proc/sendMsg.log

