
cd /eventapp4/proc
for((i=0;i<=9;i++))
do
  python predaily.py  ${i}  
done  
