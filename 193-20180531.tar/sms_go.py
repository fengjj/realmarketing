#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/sms_go.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

def getFile(index,pros):
    try:
        backupDir = "/data7/sms/backup/"
        localDir = "/data7/sms/dest/"
        remoteDir = "/ocscdr2/to_bigdata/sendsms_cdr"

        transport = paramiko.Transport(("130.51.12.14", 22))
        transport.connect(username = "sendfile" , password = "sendfile")
        tp = paramiko.SFTPClient.from_transport(transport)
        while 1:
            fileList = tp.listdir(remoteDir)
            if len(fileList) > 0:
                for fileName in fileList:
                    remoteFile = os.path.join(remoteDir, fileName)
                    backupFile = os.path.join(backupDir, fileName)
                    localFile = os.path.join(localDir, fileName)

                    tp.get(remoteFile, backupFile)
                    tp.remove(remoteFile)
                    shutil.copy(backupFile, localFile)
                    loginfo("pid:",os.getpid(),"-->",localFile)
            time.sleep(1.0)
    except Exception,ex:
        loginfo("Exception:",ex)
        os.popen('ps -ef |grep sms_go.py |grep -v grep|awk "{print $2}"|xargs kill -9')
        tp.close()
    finally:
        tp.close()

if __name__ == "__main__":
    pros = int(sys.argv[1])
    pool = multiprocessing.Pool(processes=pros)
    #0,1,2,3,4
    for index in range(0, pros):
        pool.apply_async(getFile, (index,pros))
    pool.close()
    pool.join()
