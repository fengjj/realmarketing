#. ~/.bash_profile


cd /data1/proc/

format_date=`date +%F/%T`
echo $format_date,"check" >> daemon.log

##检测url拷贝进程##
#url_num=`ps -ef | grep python | grep prefile | grep url | wc -l`
#if [ $url_num -eq 0 ];then
#    echo $format_date,"start prefile url" >> daemon.log
#    cd /data9/proc/
#    nohup python prefile.py url >> daemon.log 2>&1 &
#    cd /data1/proc/
#fi

##检测subway##
#subway_num=`ps -ef | grep python | grep subway_ | wc -l`
#if [ $subway_num -eq 0 ];then
#    echo $format_date,"start subway_zip_go" >> daemon.log
#    nohup python subway_zip_go.py >> daemon.log 2>&1 &
#fi

##检测 loc##
loc_num=`ps -ef | grep python | grep loc_zip_go | wc -l`
if [ $loc_num -eq 0 ];then
    echo $format_date,"start loc_zip_go" >> daemon.log
    nohup python loc_zip_go.py >> daemon.log 2>&1 &
fi

##检测漫游拷贝进程##
roam_num=`ps -ef | grep python | grep roam_go | wc -l`
if [ $roam_num -eq 0 ];then
    echo $format_date,"start go_roam" >> daemon.log
    nohup python roam_go.py 1 >> daemon.log 2>&1 &
fi

##检测DPI拷贝进程##
dpi_num=`ps -ef | grep python | grep dpi_zip_go_1 | wc -l`
if [ $dpi_num -eq 0 ];then
    echo $format_date,"start dpi_zip_go_1" >> daemon.log
    nohup python dpi_zip_go_1.py >> daemon.log 2>&1 &
fi

##检测weixin拷贝进程##
weixin_num=`ps -ef | grep python | grep dpi_zip_go_weixin | wc -l`
if [ $weixin_num -eq 0 ];then
    echo $format_date,"start dpi_zip_go_weixin" >> daemon.log
    nohup python dpi_zip_go_weixin.py >> daemon.log 2>&1 &
fi

##检测信令拷贝进程##
sig_num=`ps -ef | grep python | grep sig_go | wc -l`
if [ $sig_num -eq 0 ];then
    echo $format_date,"start sig_go" >> daemon.log
    nohup python sig_go.py 4 >> daemon.log 2>&1 &
fi

##检测pre拷贝进程##
pre_num=`ps -ef | grep python | grep 'prefile.py pre' | wc -l`
if [ $pre_num -eq 0 ];then
    echo $format_date,"start prefile pre" >> daemon.log
    nohup python prefile.py pre >> daemon.log 2>&1 &
fi

##检测after拷贝进程##
after_num=`ps -ef | grep python | grep prefile|grep after | wc -l`
if [ $after_num -eq 0 ];then
    echo $format_date,"start prefile after" >> daemon.log
    nohup python prefile.py after >> daemon.log 2>&1 &
fi

##检测4g拷贝进程##
fg_num=`ps -ef | grep python | grep prefile|grep 4gdata | wc -l`
if [ $fg_num -eq 0 ];then
    echo $format_date,"start prefile 4gdata" >> daemon.log
    nohup python prefile.py 4gdata >> daemon.log 2>&1 &
fi
