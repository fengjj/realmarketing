#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/update_cust.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

def getFile():
    destDir = "/data1/windowdata/custgroup/"
    remoteDir = "/data/eventapp4/yangbj/"
    if (len(sys.argv) == 2):
        fileName = "custgroup_"+sys.argv[1]+".dat"
    else:
        lastDay = datetime.datetime.now() - datetime.timedelta(days=1)
        fileName = "custgroup_"+lastDay.strftime('%Y%m%d')+".dat"
    loginfo("fileName:",fileName)
    remoteFile = os.path.join(remoteDir,fileName)
    backupFile = os.path.join(destDir,fileName)
    destFile = os.path.join(destDir,"custgroup.dat")
    delFile = os.path.join(destDir,"custgroup.del")
    transport = paramiko.Transport(("132.121.86.58", 22))
    transport.connect(username = "eventcenter" , password = "eventcenter123")
    sftp = paramiko.SFTPClient.from_transport(transport)
    sftp.get(remoteFile, backupFile)
    shutil.copy(destFile, delFile)
    shutil.copy(backupFile, destFile)
    loginfo(backupFile,"-->:",destFile)

if __name__ == "__main__":
    getFile()
