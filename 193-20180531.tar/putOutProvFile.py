#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing

def loginfo(*info):
    logfile = "/data1/proc/putOutProvFile.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

def putFile():
    ten_min_ago_time=(datetime.datetime.now()-datetime.timedelta(minutes=10)).strftime('%Y%m%d%H%M%S')
    ten_min_ago_time_m=ten_min_ago_time[0:11]
    #loginfo(ten_min_ago_time_m)
    filename="outProv_"+ten_min_ago_time_m+".pn"
    localDir = "/data1/windowdata/custgroup/keepCust2018/"
    remoteDir = "/eventcenter2/windowdata/custgroup/keepCust2018/outProv/"
    localFile = os.path.join(localDir, filename)
    remoteFile = os.path.join(remoteDir, filename)
    transport = paramiko.Transport(("132.98.23.30", 22))
    transport.connect(username = "eventcenter" , password = "eventcenter123")
    tp = paramiko.SFTPClient.from_transport(transport)
    try:
        if os.path.isfile(localFile):
                tp.put(localFile,remoteFile)
                loginfo("put done! file:",filename)
    except Exception, ex:
        loginfo(os.getpid(), ",Exception", ex)
        tp.close()

if __name__ == "__main__":
    putFile()
