. ~/.bash_profile

cd /data1/proc

format_date=`date +%F/%T`
ip=`ifconfig -a|awk '/(cast)/ {print $2}'|cut -d':' -f2|head -1`
echo ${ip}

SendMsg()
{
mysql -h 132.98.16.196 -uroot -proot123 <<!
    insert market.sys_monitor_info(time,type,level,ip,content,flag) value(now(),$1,"warn","${ip}","$2",0)
!
echo $2 >>./monitor.log
}


file_name=`awk -F '=' '{a=1}(a==1&&$2~/\//){print $1}' monitor_path.ini`
for OneCom in $file_name
	do
	file_name=$OneCom
	#echo $file_name
	###根据key从ini的session1中获得相应路径
	folder_path=`awk -F '=' '{a=1}(a==1&&$1~/'$file_name'/){print $2;exit}' monitor_path.ini`
	echo $folder_path
	###查询文件当前的修改时间
	file_update_time=`stat $folder_path|grep Modify|awk '{print $2,$3}'`
	#echo $file_update_time
	###根据文件名从ini的session2中取得上次修改时间
	last_file_update_time=`awk -F '=' '{a=1}(a==1&&$1~/'$file_name'/){print $2;exit}' monitor_time.ini`
	#echo $last_file_update_time

	###比较
	if [ "$file_update_time" = "$last_file_update_time" ];then
	    msg="${ip}主机[${file_name}]文件无变化!监控时间:${format_date}"
	    SendMsg "5" $msg
	    #echo "done"
    
	fi
	
	###更新ini中的文件修改时间应对下次比对
	file_name_update_time=$file_name"="$file_update_time
	echo $file_name_update_time >> monitor_time_tem.ini

done 

mv monitor_time_tem.ini monitor_time.ini
