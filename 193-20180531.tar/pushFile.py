#!/usr/bin/python
# encoding=utf-8

import time,datetime,sys,os
import paramiko

#动态输出日

def push(path,filename):
    t = paramiko.Transport(('132.98.17.98', 22))
    t.connect(username = 'ftp_roam',password =  'ftp_roam')
    hour = datetime.datetime.now().strftime('%Y%m%d')
    remoteDir = '/data/uploads/signal_roam/'+hour
    sftp = paramiko.SFTPClient.from_transport(t)
    try:
        try:
            sftp.stat(remoteDir)
            #print("exist")
        except IOError:
            print("not exist create :" + remoteDir)
            sftp.mkdir(remoteDir)
        remotePath = os.path.join(remoteDir, filename)
        localPath = os.path.join(path, filename)
        sftp.put(localPath,remotePath)
    except IOError:
        t.close()
        exit(1)
    finally:
        t.close()

if __name__ == '__main__':
    path = sys.argv[1]
    filename = sys.argv[2]
    push(path,filename)
