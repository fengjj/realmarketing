#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing
import zipfile

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/loc_zip_go.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")


def getFile():
    backupDir = "/data10/prefile/loc/backup/"
    localDir = "/data10/prefile/loc/dest/"
    remoteDir = "/GD_LOCATION/"
    transport = paramiko.Transport(("132.96.56.74", 2222))
    transport.connect(username = "Gd_location" , password = "Gd_location123")
    tp = paramiko.SFTPClient.from_transport(transport)
    try:
        while 1:
            fileList = tp.listdir(remoteDir)
            if len(fileList) > 0:
                for fileName in fileList:
                    if (("zip" in fileName) and not ("tmp" in fileName)):
                        remoteFile = os.path.join(remoteDir, fileName)
                        loginfo("start:", remoteFile)
                        date = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]
                        hourbBackupDir = os.path.join(backupDir, date[:8])
                        if not os.path.exists(hourbBackupDir):
                            os.mkdir(hourbBackupDir)

                        backupFile = os.path.join(hourbBackupDir, fileName)
                        tp.get(remoteFile, backupFile)
                        tp.remove(remoteFile)
                        f = zipfile.ZipFile(backupFile, mode='r')
                        for file in f.namelist():
                            f.extract(file, hourbBackupDir)
                            os.remove(backupFile)
                            file_date = fileName + "_" + date
                            file_date = file_date.replace('zip', fileName[12:26])
                            shutil.copy(os.path.join(hourbBackupDir, fileName.replace('zip', 'txt')),
                                        os.path.join(localDir, file_date))
                        loginfo("pid:", os.getpid(), " end :", fileName)
            time.sleep(3.0)
    except Exception,ex:
        loginfo("kill,Exception",ex)
        os.popen("ps -ef|grep python |grep loc_zip_go|awk '{print $2}'|xargs kill -9")
        tp.close()
    tp.close()

if __name__ == "__main__":
    getFile()
