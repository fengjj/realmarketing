. ~/.bash_profile

cd /data1/proc

format_date=`date +%F/%T`
ip=`ifconfig -a|awk '/(cast)/ {print $2}'|cut -d':' -f2|head -1`
echo ${ip}
SendMsg()
{
mysql -h 132.98.16.196 -uroot -proot123 <<!
    insert market.sys_monitor_info(time,type,level,ip,content,flag) value(now(),$1,"warn","${ip}","$2",0)
!
echo $2 >>./monitor.log
}

###监控subway文件积压###
#subway_file_num=`ls -l /data10/prefile/subway/dest/ |grep "^-"|wc -l`
#if [ $subway_file_num -gt 50 ];then
#    msg="${ip}主机[subway]详单文件积压[${subway_file_num}]个!监控时间:${format_date}"
#    SendMsg "5" $msg
#    `ps -ef|grep Subway|grep data1|grep -v grep|awk '{print $2}'|xargs kill -9`
#    `cd /data1/locationevent/bin;sh startup.sh Subway`
#fi

###监控url文件积压###
#url_file_num=`ls -l /data9/prefile/url/video_tag/ |grep "^-"|wc -l`
#if [ $url_file_num -gt 50 ];then
#    msg="${ip}主机[url]详单文件积压[${url_file_num}]个!监控时间:${format_date}"
#    SendMsg "5" $msg
#    `ps -ef|grep ReadDpiFileToLabelKafka|grep url|grep -v grep|awk '{print $2}'|xargs kill -9`
#    `cd /data4/locationevent/bin;sh readDpiFileToLabelKafka.sh url`
#fi

###监控loc文件积压###
loc_file_num=`ls -l /data10/prefile/loc/dest/ |grep "^-"|wc -l`
if [ $loc_file_num -gt 50 ];then
    msg="${ip}主机[室分loc]详单文件积压[${loc_file_num}]个!监控时间:${format_date}"
    SendMsg "5" $msg
    `ps -ef|grep "ReadDpiFileToLabelKafka loc"|grep -v grep|awk '{print $2}'|xargs kill -9`
    `cd /data1/locationevent/bin;sh readDpiFileToLabelKafka.sh loc`
fi

###监控漫游信令文件积压###
roam_file_num=`ls -l /data8/roam/dest/ |grep "^-"|wc -l`
if [ $roam_file_num -gt 50 ];then
    msg="${ip}主机[漫游信令]详单文件积压[${roam_file_num}]个!监控时间:${format_date}"
    SendMsg "5" $msg
    `ps -ef|grep ReadDpiFileToLabelKafka|grep roam|grep -v grep|awk '{print $2}'|xargs kill -9`
    `cd /data1/locationevent/bin;sh readDpiFileToLabelKafka.sh roam`
fi

###监控weixin详单文件积压###
weixin_file_num=`ls -l /data3/prefile/weixin/ |grep "^-"|wc -l`
if [ $weixin_file_num -gt 50 ];then
    msg="${ip}主机[weixin]详单文件积压[${weixin_file_num}]个!监控时间:${format_date}"
    SendMsg "5" $msg
    `ps -ef|grep ReadDpiFileToLabelKafka|grep weixin|grep -v grep|awk '{print $2}'|xargs kill -9`
    `cd /data1/locationevent/bin;sh readDpiFileToLabelKafka.sh weixin`
fi

###监控DPI详单文件积压###
dpi_file_num=`ls -l /data3/prefile/dpi/ |grep "^-"|wc -l`
if [ $dpi_file_num -gt 50 ];then
    msg="${ip}主机[DPI]详单文件积压[${dpi_file_num}]个!监控时间:${format_date}"
    SendMsg "5" $msg
    `ps -ef|grep ReadDpiFileToLabelKafka|grep dpi|grep -v grep|awk '{print $2}'|xargs kill -9`
    `cd /data1/locationevent/bin;sh readDpiFileToLabelKafka.sh dpi`
fi

###监控信令文件积压###
sign_file_num=`ls -l /data4/prefile/sig/ |grep "^-"|wc -l`
if [ $sign_file_num -gt 50 ];then
    msg="${ip}主机[信令]文件积压[${sign_file_num}]个!监控时间:${format_date}"
    SendMsg "5" $msg
    `ps -ef|grep ParseSignalMessageAdapter|grep -v grep|awk '{print $2}'|xargs kill -9`
    `cd /data4/locationevent/bin;sh startup.sh ParseSignalMessageAdapter`
fi

###监控语音详单文件积压###
voice_file_num=`ls -l /data10/prefile/voice/dest/ |grep "^-"|wc -l`
if [ $voice_file_num -gt 2000 ];then
    msg="${ip}主机[语音]详单文件积压[${voice_file_num}]个!监控时间:${format_date}"
    `ps -ef|grep VoiceFileToKafka|grep -v grep|awk '{print $2}'|xargs kill -9`
    `sh /data1/locationevent/bin/dataBridge.sh VoiceFileToKafka`
    SendMsg "5" $msg
fi

###监控后付费详单文件积压###
after_file_num=`ls -l /data6/after/dest/ |grep "^-"|wc -l`
if [ $after_file_num -gt 1000 ];then
    msg="${ip}主机[后付费]详单文件积压[${after_file_num}]个!监控时间:${format_date}"
    `ps -ef|grep ParseFlowFileToKafka|grep -v grep|awk '{print $2}'|xargs kill -9`
    `sh /data4/locationevent/bin/startup.sh ParseFlowFileToKafka`
    SendMsg "5" $msg
fi

###监控预付费详单文件积压###
pre_file_num=`ls -l /data7/pre/dest/ |grep "^-"|wc -l`
if [ $pre_file_num -gt 2000 ];then
    msg="${ip}主机[预付费]详单文件积压[${pre_file_num}]个!监控时间:${format_date}"
    `ps -ef|grep ParsePreFlowFileToKafka|grep -v grep|awk '{print $2}'|xargs kill -9`
    `sh /data4/locationevent/bin/startup.sh ParsePreFlowFileToKafka`
    SendMsg "5" $msg
fi

###监控4G详单文件积压###
x4g_file_num1=`ls -l /data11/4g/dest/ |grep "^-"|wc -l`
x4g_file_num2=`ls -l /data11/4g/backup/ |grep "^-"|wc -l`
if [ $x4g_file_num1 -gt 2000 ] || [ $x4g_file_num2 -gt 2000 ];then
    msg="${ip}主机[4g]详单文件积压 dest:[${x4g_file_num1}]个,backpu[${x4g_file_num2}]个!监控时间:${format_date}"
    `ps -ef|grep Parse4GFlowFileToKafka|grep -v grep|awk '{print $2}'|xargs kill -9`
    `sh /data4/locationevent/bin/startup.sh Parse4GFlowFileToKafka`
    SendMsg "5" $msg
fi



###监控subway/loc/voice[data10]文件空间--开始######
Avail=`df -h |grep /data10|awk '{print $4}'`
Use=`df -h |grep /data10|awk '{print $5}'`
if [[ ${Use} > "95%" ]];then
    msg="${ip}主机[磁盘/data10]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
    SendMsg "2" $msg
fi

###监控url[data9]文件空间--开始######
#Avail=`df -h |grep /data9|awk '{print $4}'`
#Use=`df -h |grep /data9|awk '{print $5}'`
#if [[ ${Use} > "95%" ]];then
#    msg="${ip}主机[磁盘/data9]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
#    SendMsg "2" $msg
#fi

###监控漫游信令[data8]文件空间--开始######
Avail=`df -h |grep /data8|awk '{print $4}'`
Use=`df -h |grep /data8|awk '{print $5}'`
if [[ ${Use} > "95%" ]];then
    msg="${ip}主机[磁盘/data8]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
    SendMsg "2" $msg
fi

###监控dpi[data3]文件空间--开始######
Avail=`df -h |grep /data3|awk '{print $4}'`
Use=`df -h |grep /data3|awk '{print $5}'`
if [[ ${Use} > "95%" ]];then
    msg="${ip}主机[磁盘/data3]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
    SendMsg "2" $msg
fi

###监控后付费[data6]文件空间--开始######
Avail=`df -h |grep /data6|awk '{print $4}'`
Use=`df -h |grep /data6|awk '{print $5}'`
if [[ ${Use} > "95%" ]];then
    msg="${ip}主机[磁盘/data6]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
    SendMsg "2" $msg
fi

###监控预付费[data7]文件空间--开始######
Avail=`df -h |grep /data7|awk '{print $4}'`
Use=`df -h |grep /data7|awk '{print $5}'`
if [[ ${Use} > "95%" ]];then
    msg="${ip}主机[磁盘/data7]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
    SendMsg "2" $msg
fi

###监控4G[data11]文件空间--开始######
Avail=`df -h |grep /data11|awk '{print $4}'`
Use=`df -h |grep /data11|awk '{print $5}'`
if [[ ${Use} > "95%" ]];then
    msg="${ip}主机[磁盘/data11]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
    SendMsg "2" $msg
fi



###监控程序日志[data1]文件空间--开始######
Avail=`df -h |grep /data1|awk '{print $4}'`
Use=`df -h |grep /data1|awk '{print $5}'`
if [[ ${Use} > "95%" ]];then
    msg="${ip}主机[磁盘/data1]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
    SendMsg "2" $msg
fi

###监控旧程序日志[data4]文件空间--开始######
Avail=`df -h |grep /data4|awk '{print $4}'`
Use=`df -h |grep /data4|awk '{print $5}'`
if [[ ${Use} > "95%" ]];then
    msg="${ip}主机[磁盘/data4]已使用[${Use}],剩余[${Avail}]!监控时间:${format_date}"
    SendMsg "2" $msg
fi



#监控主机内存
free=`free -g|grep "Mem"|awk '{print $4}'`
used=`free -g|grep "Mem"|awk '{print $3}'`
if [ ${free} -lt 1 ];then
    msg="${ip}主机[内存]已使用[${used}G],剩余[${free}G]!监控时间:${format_date}"
    SendMsg "0" $msg
fi

#监控esp进程
#esp_num=`esp_cluster_admin --uri=esp://132.98.16.193:19011 --username=sap  --password=sap123  --get_projects|grep businessproject|wc -l`
#if [ ${esp_num} -lt 20 ];then
#    msg="${ip}ESP集群businessproject数量少于20个!监控时间:${format_date}"
#    SendMsg "0" $msg
#fi

#监控kafka积压
zookeeper=132.98.16.194:2180,132.98.16.195:2180,132.98.16.196:2180
group=realtimeMarket2_Tlabelmsg
sh /data2/kafka_2.10-0.8.2.2/bin/kafka-run-class.sh kafka.tools.ConsumerOffsetChecker --zookeeper ${zookeeper} --group ${group} > k_topic.dat
awk '{a[$2]=a[$2]==""?$6:a[$2]","$6}END{for(i in a){c=split(a[i],b,",");if(c>2){sum=0;for(j in b){sum+=b[j]};if(sum>2000000){print i"]积压:"sum | "sort"}}}}' k_topic.dat > k_send.dat
cat k_send.dat|while read line
do
    msg="主题[${line}!监控时间:${format_date}"
    SendMsg "6" $msg
done

group=sub_flowmsg
sh /data2/kafka_2.10-0.8.2.2/bin/kafka-run-class.sh kafka.tools.ConsumerOffsetChecker --zookeeper ${zookeeper} --group ${group} > k_topic.dat
awk '{a[$2]=a[$2]==""?$6:a[$2]","$6}END{for(i in a){c=split(a[i],b,",");if(c>2){sum=0;for(j in b){sum+=b[j]};if(sum>100000){print i"]积压:"sum | "sort"}}}}' k_topic.dat > k_send.dat
cat k_send.dat|while read line
do
    msg="主题[${line}!监控时间:${format_date}"
    SendMsg "6" $msg
done
