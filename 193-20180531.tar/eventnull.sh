. ~/.bash_profile

cd /data1/proc

format_date=`date +%F/%T`
ip=`ifconfig -a|awk '/(cast)/ {print $2}'|cut -d':' -f2|head -1`
echo ${ip}

SendMsg()
{
mysql -h 132.98.16.196 -uroot -proot123 <<!
    insert market.sys_monitor_info(time,type,level,ip,content,flag) value(now(),$1,"warn","${ip}","$2",0)
!
echo $2 >>./monitor.log
}

getMsg()
{
depts=`mysql -h 132.98.16.196 -uroot -proot123 <<!
		use market;
    select concat(event_id,':',event_name,':',event_type) title from 
			(select e.event_id,e.event_name,e.event_type,sum(count) sum
			from mk_event_info e LEFT JOIN mk_monitor_info m on  m.event_id = e.event_id and m.year=date_format(now(), '%Y') 
				and m.month=date_format(now(), '%m') and m.day = date_format(now(), '%d')
			where e.status_code = '04'
			group by e.event_id) cc
			where cc.sum is null
			order by cc.event_id;
!`
for d in $depts; do
    ###比较
        if [ "$d" != "title" ];then
            msg="场景：[${d}]无数据触发!监控时间:${format_date}"
            SendMsg "5" $msg
            #echo "done"
    
        fi
done
}

getMsg
