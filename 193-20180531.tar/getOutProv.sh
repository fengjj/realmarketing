. ~/.bash_profile

#193捞取语音话单和漫游信令省外漫游号码

# 201801231710
cmin10bf=`date +'%Y%m%d%H%M' -d '-10 min'`
cmin10bfd=${cmin10bf:0:8}
cmin10bfh=${cmin10bf:0:10}
cmin10bfm=${cmin10bf:0:11}

#echo "${cmin10bf},${cmin10bfd},${cmin10bfh},${cmin10bfm}"

`awk -F "|" '{if($5=="460" && $7!="") {print $4}}' /data8/roam/backup/${cmin10bfd}/GD_ROAM_${cmin10bfm}*|sort|uniq  > /data1/windowdata/custgroup/keepCust2018/outProv_${cmin10bfm}_roam.pn `
`awk -F "," '{if($52=="4") {print $13}}' /data10/prefile/voice/dest_backup/${cmin10bfh}/VGP_BDC_*${cmin10bfm}* |sort|uniq  > /data1/windowdata/custgroup/keepCust2018/outProv_${cmin10bfm}_voice.pn `
awk '{if( length($0)==11 && substr($0,1,1)=="1" && substr($0,1,3)!="106" && substr($0,1,3)!="145" ){print $0}}' /data1/windowdata/custgroup/keepCust2018/outProv_${cmin10bfm}_roam.pn /data1/windowdata/custgroup/keepCust2018/outProv_${cmin10bfm}_voice.pn |sort|uniq > /data1/windowdata/custgroup/keepCust2018/outProv_${cmin10bfm}.pn

python putOutProvFile.py
