
cd /eventapp4/proc
for((i=0;i<=9;i++))
do
  python daily.py  ${i}  
done  
