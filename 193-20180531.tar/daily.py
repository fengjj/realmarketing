import ConfigParser 
import string, os, sys
import paramiko
import re
import time,datetime


def init(paras,cfgname):
    print cfgname
    cf = ConfigParser.ConfigParser()
    cf.read(cfgname)            
    s = cf.sections()               
    for board in cf.items('file'): 
        #print board[0]+'='+board[1] 
        if board[0] == 'src_dir':
            paras[0] = board[1] 
        if board[0] == 'dest_dir':
            paras[1] = board[1]                           
    print  paras[0],paras[1]
    paras[2]=sys.argv[1]

def dealfile(paras,type=''):

    currentday=datetime.datetime.now().strftime("%Y%m%d%H%M")
    flowwindow_dict={}
    out_dict={}
    
    usedwindow_file="%s/flowevent_day_%s" % (paras[0],paras[2])
    UsedDailyDataFlowWindow = "UsedDailyDataFlowWindow"
    if type=='4g':
        usedwindow_file="%s/flowevent_day_4g_%s" % (paras[0],paras[2])
        UsedDailyDataFlowWindow = "UsedDaily4GDataFlowWindow"
    print "usedwindow_file=",usedwindow_file
    
    outfile='%s/%s%s%s' % (paras[1],UsedDailyDataFlowWindow,currentday[0:11],"000.txt")  
    output = open(outfile, 'a')
    
    file_object=open(usedwindow_file,'r')
    
    for line in file_object:
    

        Msisdn=line.split(' ')[1].split('=')[1].replace('"','')
        FeeCode=line.split(' ')[2].split('=')[1].replace('"','')
        DataFlow=line.split(' ')[3].split('=')[1].replace('"','')
        LeftDataFlow=line.split(' ')[4].split('=')[1].replace('"','')
        FlowTime=line.split(' ')[5].split('=')[1].replace('"','')
        MinFlowTime=line.split(' ')[6].split('=')[1].replace('"','')
        HomeAreaCode=line.split(' ')[7].split('=')[1].replace('"','')
        Userid=line.split(' ')[8].split('=')[1].replace('"','')
        FlowDate=line.split(' ')[9].split('=')[1].replace('"','')  
        TotalDataFlow=line.split(' ')[10].split('=')[1].replace('"','') 
        
        key_str="%s,%s,%s,%s,%s,%s,%s,%s,%s,%s" % (Msisdn,FeeCode,DataFlow,LeftDataFlow,FlowTime,MinFlowTime,HomeAreaCode,Userid,FlowDate,TotalDataFlow)
        output.writelines("%s\n" % key_str )     
    file_object.close()
    
     
    output.close()   
    
  
           
def main(cfgname):
    paras=["","",""]        
    init(paras,cfgname) 
 
    
    print paras    
    dealfile(paras)     
    dealfile(paras,'4g')     

if __name__ == '__main__':
    main('daily.cfg')


