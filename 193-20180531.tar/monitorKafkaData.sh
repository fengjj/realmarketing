. ~/.bash_profile
zookeeper=132.98.16.194:2180,132.98.16.195:2180,132.98.16.196:2180,132.98.23.30:2180,132.98.23.31:2180
group=JXHYX_GD_51
topic=Tdata000
echo `date +%F/%T` >> monitorKafkaData.txt
sh /data2/kafka_2.10-0.8.2.2/bin/kafka-run-class.sh kafka.tools.ConsumerOffsetChecker --zookeeper ${zookeeper} --group ${group} --topic ${topic} >>monitorKafkaData.txt
