#!/bin/bash
#. ~/.bash_profile

cd /data1/proc/

date=`date +'%Y-%m-%d %H:%M:%S'`
#count=`ps -ef | grep check_subscriber.sh | grep -v grep | wc -l`
#if [ ${count} -gt 2 ]; then
#        echo "${date} count=${count} check_subscriber.sh is running!! PID: "
#        ps -ef | grep check_subscriber.sh | grep -v grep
#        exit 2
#fi

#subway 文件处理入库
#Subway_num=`ps -ef | grep Subway | grep data1 | wc -l`
#if [ ${Subway_num} -eq 1 ]; then
#    echo "[${date}] GOOD! ${Subway_num} Subway is running!"
#else
#    if [ ${Subway_num} -lt 1 ]; then
#        echo "[${date}] Subway is dead,try to restart..."
#        sh /data1/locationevent/bin/startup.sh Subway
#    fi
#fi

#视频url 文件入库
#nums=`ps -ef|grep readDpiFileToLabelKafka|grep url| grep -v grep | wc -l`
#if [ ${nums} -eq 1 ]; then
#    echo "[${date}] GOOD! ${nums} readDpiFileToLabelKafka_url is running!"
#else
#    if [ ${nums} -lt 1 ]; then
#        echo "[${date}] readDpiFileToLabelKafka_url is dead,try to restart..."
#        sh /data4/locationevent/bin/readDpiFileToLabelKafka.sh url
#    fi
#fi

#loc
nums=`ps -ef|grep "readDpiFileToLabelKafka_loc"| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} readDpiFileToLabelKafka_loc is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] readDpiFileToLabelKafka_loc is dead,try to restart..."
        sh /data1/locationevent/bin/readDpiFileToLabelKafka.sh loc
    fi
fi

#roam 文件入库
nums=`ps -ef|grep readDpiFileToLabelKafka|grep roam| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} readDpiFileToLabelKafka_roam is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] readDpiFileToLabelKafka_roam is dead,try to restart..."
        sh /data1/locationevent/bin/readDpiFileToLabelKafka.sh roam
    fi
fi

#weixin 文件入库
nums=`ps -ef|grep readDpiFileToLabelKafka|grep weixin| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} readDpiFileToLabelKafka_weixin is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] readDpiFileToLabelKafka_weixin is dead,try to restart..."
	sh /data1/locationevent/bin/readDpiFileToLabelKafka.sh weixin
    fi
fi

#dpi 文件入库
nums=`ps -ef|grep readDpiFileToLabelKafka|grep dpi| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} readDpiFileToLabelKafka_dpi is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] readDpiFileToLabelKafka_dpi is dead,try to restart..."
        sh /data1/locationevent/bin/readDpiFileToLabelKafka.sh dpi
    fi
fi

#信令 文件入库
nums=`ps -ef | grep ParseSignalMessageAdapter |grep data4| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} ParseSignalMessageAdapter is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] ParseSignalMessageAdapter is dead,try to restart..."
        sh /data4/locationevent/bin/startup.sh ParseSignalMessageAdapter
    fi
fi

#4G 文件入库
nums=`ps -ef | grep Parse4GFlowFileToKafka |grep data4| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} Parse4GFlowFileToKafka is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] Parse4GFlowFileToKafka is dead,try to restart..."
        sh /data4/locationevent/bin/startup.sh Parse4GFlowFileToKafka
    fi
fi

#pre 文件入库
nums=`ps -ef | grep ParsePreFlowFileToKafka |grep data4| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} ParsePreFlowFileToKafka is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] ParsePreFlowFileToKafka is dead,try to restart..."
        sh /data4/locationevent/bin/startup.sh ParsePreFlowFileToKafka
    fi
fi

#after 文件入库
nums=`ps -ef | grep ParseFlowFileToKafka |grep data4| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} ParseFlowFileToKafka is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] ParseFlowFileToKafka is dead,try to restart..."
        sh /data4/locationevent/bin/startup.sh ParseFlowFileToKafka
    fi
fi

#voice 文件入库
nums=`ps -ef | grep VoiceFileToKafka |grep data1| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} VoiceFileToKafka is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] VoiceFileToKafka is dead,try to restart..."
        sh /data1/locationevent/bin/dataBridge.sh VoiceFileToKafka
    fi
fi

#挂机客户群kafka入esp
nums=`ps -ef | grep PublishSigCust |grep data1| grep -v grep | wc -l`
if [ ${nums} -eq 1 ]; then
    echo "[${date}] GOOD! ${nums} PublishSigCust is running!"
else
    if [ ${nums} -lt 1 ]; then
        echo "[${date}] PublishSigCust is dead,try to restart..."
        cd /data1/locationevent/bin
        sh publishSigCust.sh
    fi
fi
