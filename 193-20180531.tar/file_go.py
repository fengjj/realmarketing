#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import ConfigParser, shutil, multiprocessing


#初始化，读取配置
def getCfg(cfgFile):
    cfgDict = {}
    cf = ConfigParser.ConfigParser()
    cf.read(cfgFile)
    for kv in cf.items(sys.argv[1]):
        cfgDict[kv[0]] = kv[1]
    return cfgDict

def getDestDirs(cfgDict):
    destDirs = {}
    #cl:/data6/after/dest/,s^go:/data6/after/test/
    for kv in cfgDict['dest_dirs'].split(','):
        kvs = kv.split(':')
        destDirs[kvs[0]] = kvs[1]
    return destDirs

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/"+sys.argv[1]+"_go.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

def getHourBackupDir(destDir):
    if destDir.endswith("/"):
        destDir = destDir[:-1]
    backupDir = destDir + "_backup"
    if not os.path.exists(backupDir):
        os.mkdir(backupDir)
    hour = datetime.datetime.now().strftime('%Y%m%d%H')
    hourBackupDir = os.path.join(backupDir, hour)
    if not os.path.exists(hourBackupDir):
        os.mkdir(hourBackupDir)
    return hourBackupDir

def moveFile(fileName, cfgDict, destDirs):
    try:
        originFile = os.path.join(cfgDict["origin_dir"], fileName)
        #ctime = os.stat(originFile).st_ctime
        #date = time.strftime('%Y%m%d%H%M%S', time.localtime(ctime))
        for prefix in destDirs:
            destDir = destDirs[prefix]
            destFile = os.path.join(destDir, fileName)
            hourBackupDir = getHourBackupDir(destDir)
            backupFile = os.path.join(hourBackupDir, fileName)
            if fileName.startswith(prefix):
                shutil.copy(originFile, backupFile)
                shutil.copy(backupFile, destFile)
                loginfo(os.getpid(), "-->", destFile)
            elif '^' in prefix:
                pres = prefix.split('^')
                if fileName.startswith(pres[0]) and pres[1] in fileName:
                    shutil.copy(originFile, backupFile)
                    shutil.copy(backupFile, destFile)
                    loginfo(os.getpid(), "-->", destFile)

        os.remove(originFile)
        #loginfo("remove:", originFile)
    except Exception,ex:
        loginfo("Exception:",ex)

if __name__ == "__main__":
    cfgDict = getCfg("/data1/proc/file_go.cfg")
    destDirs = getDestDirs(cfgDict)
    pool = multiprocessing.Pool(processes=2)
    fileSet = set([])
    while 1:
        fileList = os.listdir(cfgDict["origin_dir"])
        if len(fileList) > 0:
            for fileName in fileList:
                if fileName in fileSet:
                    continue
                pool.apply_async(moveFile, (fileName, cfgDict, destDirs, ))
                fileSet.add(fileName)
        time.sleep(1.0)
    pool.close()
    pool.join()
