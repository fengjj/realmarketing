#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/clear_log.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

if __name__ == "__main__":
    logDir = "/data1/locationevent/log/"
    threeDayAgo = datetime.datetime.now() - datetime.timedelta(days=3)
    suffix = threeDayAgo.strftime('%Y%m%d')
    loginfo("suffix:"+suffix)
    fileList = os.listdir(logDir)
    if len(fileList) > 0:
        for fileName in fileList:
            if (fileName.endswith(suffix)):
                deleteFile = os.path.join(logDir,fileName)
                os.remove(deleteFile)
                loginfo("delete:"+deleteFile)
    logDir = "/data4/locationevent/log/"
    threeDayAgo = datetime.datetime.now() - datetime.timedelta(days=3)
    suffix = threeDayAgo.strftime('%Y%m%d')
    loginfo("suffix:"+suffix)
    fileList = os.listdir(logDir)
    if len(fileList) > 0:
        for fileName in fileList:
            if (fileName.endswith(suffix)):
                deleteFile = os.path.join(logDir,fileName)
                os.remove(deleteFile)
                loginfo("delete:"+deleteFile)

