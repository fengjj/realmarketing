. ~/.bash_profile

data_dir=/data1/windowdata/after/
cd $data_dir
dir_name=`date +'%Y%m%d%H' -d '+10 minutes' `
if [ ! -d "$dir_name" ];then
    mkdir $dir_name
fi
cd $dir_name

zookeeper=132.98.16.194:2180,132.98.16.195:2180,132.98.16.196:2180,132.98.23.30:2180,132.98.23.31:2180
#zookeeper=132.121.86.57:2181,132.121.86.103:2181,132.121.86.104:2181
group=sub_flowmsg
esp=132.98.23.30:19011/mywork/flowevent
echo `date +%F/%T`
for((i=0;i<10;i++))
do
    echo "bakup: "${esp}${i}
    sh /data2/kafka_2.10-0.8.2.2/bin/kafka-run-class.sh kafka.tools.ConsumerOffsetChecker --zookeeper ${zookeeper} --group ${group} --topic Tflowmsg_${i} >Tflowmsg_${i}.txt
    esp_query -p ${esp}${i} -c sap:sap123 -Q "select Msisdn,RoamType,DataFlow,FlowTime,HomeAreaCode,Userid,PayFee,VisitAreaCode from UsedDataFlowWindow" >flowevent_${i} &
    esp_query -p ${esp}${i} -c sap:sap123 -Q "select Msisdn,FeeCode,DataFlow,LeftDataFlow,FlowTime,MinFlowTime,HomeAreaCode,Userid,FlowDate,TotalDataFlow from UsedDailyDataFlowWindow" >flowevent_day_${i} &
done

echo `date +%F/%T`
echo "done-->${data_dir}${dir_name}"
exit
