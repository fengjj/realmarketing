. ~/.bash_profile

cd /data1/proc/
mysql -h 132.98.16.196 -uroot -proot123 <<!
    update market.mk_event_info set status_code="$2" where event_id = "$1"
!
echo date:$1 $2 >>./auto_config_mysql.log

