after_file_num=`ls -l /data6/after/dest/ |grep "^-"|wc -l`
if [ $after_file_num -gt 1000 ];then
    echo "${ip}主机[后付费]详单文件积压[${after_file_num}]个!监控时间:${format_date}"
    ps -ef|grep ParseFlowFileToKafka|grep -v grep|awk '{print $2}'|xargs kill -9
    sh /data4/locationevent/bin/startup.sh ParseFlowFileToKafka
fi
