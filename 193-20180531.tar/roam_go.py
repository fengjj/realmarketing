#!/usr/bin/python
# -*- coding:utf-8 -*-

import os, sys
import time, datetime
import paramiko,shutil,multiprocessing

#动态输出日志
def loginfo(*info):
    logfile = "/data1/proc/roam_go.log"
    with open(logfile, 'a') as output:
        msg = reduce(lambda x,y:str(x)+str(y),info)
        currtime = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"]  "
        output.write(currtime+msg+"\n")

def push(path,filename):
    t = paramiko.Transport(('132.98.17.98', 22))
    t.connect(username = 'ftp_roam',password =  'ftp_roam')
    hour = datetime.datetime.now().strftime('%Y%m%d')
    remoteDir = '/data/uploads/signal_roam/'+hour
    sftp = paramiko.SFTPClient.from_transport(t)
    try:
        try:
            sftp.stat(remoteDir)
            #print("exist")
        except IOError:
            loginfo("not exist create :" , remoteDir)
            sftp.mkdir(remoteDir)
        remotePath = os.path.join(remoteDir, filename)
        localPath = os.path.join(path, filename)
        sftp.put(localPath,remotePath)
    except IOError:
        t.close()
        exit(1)
    finally:
        t.close()

def getFile():
    backupDir = "/data8/roam/backup/"
    localDir = "/data8/roam/dest/"
    remoteDir = "/GD_ROAM/"
    transport = paramiko.Transport(("132.96.56.74", 2222))
    transport.connect(username = "Gd_roam" , password = "Gd_roam123")
    tp = paramiko.SFTPClient.from_transport(transport)
    while 1:
        try:
            fileList = tp.listdir(remoteDir)
            if len(fileList) > 0:
                for fileName in fileList:
                    if(not ("tmp" in fileName) and ("txt" in fileName)):
                        remoteFile = os.path.join(remoteDir, fileName)
                        mtime = time.localtime(tp.stat(remoteFile).st_mtime)
                        createTime = time.strftime('%Y%m%d%H%M%S',mtime)
                        fileName = fileName.replace('txt', createTime)
                        timeBackupDir = os.path.join(backupDir, createTime[:8])
                        if not os.path.exists(timeBackupDir):
                            os.mkdir(timeBackupDir)
                        backupFile = os.path.join(timeBackupDir, fileName)
                        localFile = os.path.join(localDir, fileName)
                        tp.get(remoteFile, backupFile)
                        tp.remove(remoteFile)
                        shutil.copy(backupFile, localFile)
                        push(timeBackupDir, fileName)
                        loginfo("pid:", os.getpid(), "-->", backupFile)
            time.sleep(3.0)
        except Exception,ex:
            if("GD_ROAM" in ex):
                loginfo(os.getpid(),",Exception",ex)
            else:
                loginfo("kill,Exception",ex)
                os.popen("ps -ef|grep python |grep roam_go|awk '{print $2}'|xargs kill -9")
                tp.close()

if __name__ == "__main__":
    getFile()
